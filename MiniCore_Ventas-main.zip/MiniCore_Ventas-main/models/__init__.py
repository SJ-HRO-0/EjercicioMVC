from .vendedor import Vendedor
from .venta import Venta
from .regla import Regla